#!/bin/bash
echo "ci3465@QNET.QUALNET.ORG ALL=(root) NOPASSWD:ALL" >> /etc/sudoers
/root/.deploy-bellese.sh