# HQR-Terraform

These Terraform scripts will provide the templates needed for most infrastructure configurations and deployments for the HQR project as a whole.


## Updating Infrastructure

This section will go over how to modify an existing EC2 instance with Terraform.

The [`terraform init`](https://www.terraform.io/docs/commands/init.html) command is used to initialize a working directory containing Terraform configuration files. This is the first command that should be run after writing a new Terraform configuration or cloning an existing one from version control. It is safe to run this command multiple times.

As you change Terraform configurations, Terraform builds an execution plan that only modifies what is necessary to reach your desired state.

The [`terraform plan`](https://www.terraform.io/docs/commands/plan.html) command is used to create an execution plan. Terraform performs a refresh, unless explicitly disabled, and then determines what actions are necessary to achieve the desired state specified in the configuration files.

This command is a convenient way to check whether the execution plan for a set of changes matches your expectations without making any changes to real resources or to the state. For example, `terraform plan` might be run before committing a change to version control, to create confidence that it will behave as expected.

### Configuration

To modify the AMI of your instance, edit the `aws_instance.example` resource in your configuration and change it to the following:

```
resource "aws_instance" "example" {
  ami           = "ami-b374d5a5"
  instance_type = "t2.micro"
}
```

You can also completely remove resources and Terraform will know to destroy the old one.

### Apply Changes

After changing the configuration, run `terraform apply` to see how Terraform will apply this change to the existing resources.

```
$ terraform apply
# ...

-/+ aws_instance.example
    ami:                      "ami-2757f631" => "ami-b374d5a5" (forces new resource)
    availability_zone:        "us-east-1a" => "<computed>"
    ebs_block_device.#:       "0" => "<computed>"
    ephemeral_block_device.#: "0" => "<computed>"
    instance_state:           "running" => "<computed>"
    instance_type:            "t2.micro" => "t2.micro"
    private_dns:              "ip-172-31-17-94.ec2.internal" => "<computed>"
    private_ip:               "172.31.17.94" => "<computed>"
    public_dns:               "ec2-54-82-183-4.compute-1.amazonaws.com" => "<computed>"
    public_ip:                "54.82.183.4" => "<computed>"
    subnet_id:                "subnet-1497024d" => "<computed>"
    vpc_security_group_ids.#: "1" => "<computed>"
```

The prefix -/+ means that Terraform will destroy and recreate the resource, rather than updating it in-place. While some attributes can be updated in-place (which are shown with the ~ prefix), changing the AMI for an EC2 instance requires recreating it. Terraform handles these details for you, and the execution plan makes it clear what Terraform will do.

Additionally, the execution plan shows that the AMI change is what required the resource to be replaced. Using this information, you can adjust your changes to possibly avoid destroy/create updates if they are not acceptable in some situations.

Once again, Terraform prompts for approval of the execution plan before proceeding. Answer `yes` to execute the planned steps:

```
# ...
aws_instance.example: Refreshing state... (ID: i-64c268fe)
aws_instance.example: Destroying...
aws_instance.example: Destruction complete
aws_instance.example: Creating...
  ami:                      "" => "ami-b374d5a5"
  availability_zone:        "" => "<computed>"
  ebs_block_device.#:       "" => "<computed>"
  ephemeral_block_device.#: "" => "<computed>"
  instance_state:           "" => "<computed>"
  instance_type:            "" => "t2.micro"
  key_name:                 "" => "<computed>"
  placement_group:          "" => "<computed>"
  private_dns:              "" => "<computed>"
  private_ip:               "" => "<computed>"
  public_dns:               "" => "<computed>"
  public_ip:                "" => "<computed>"
  root_block_device.#:      "" => "<computed>"
  security_groups.#:        "" => "<computed>"
  source_dest_check:        "" => "true"
  subnet_id:                "" => "<computed>"
  tenancy:                  "" => "<computed>"
  vpc_security_group_ids.#: "" => "<computed>"
aws_instance.example: Still creating... (10s elapsed)
aws_instance.example: Still creating... (20s elapsed)
aws_instance.example: Creation complete

Apply complete! Resources: 1 added, 0 changed, 1 destroyed.

# ...
```

As indicated by the execution plan, Terraform first destroyed the existing instance and then created a new one in its place. You can use `terraform show` to see the new values associated with this instance.


## Provisioning

This section will go over how to set up a provisioner to initialize instances when they're created.

Use provisioners when you need to do some initial setup on your instances. Provisioners let you upload files, run shell scripts, or install and trigger other software like configuration management tools, etc.

### Defining a Provisioner

To define a provisioner, modify the resource block defining the "example" EC2 instance to look like the following:

```
resource "aws_instance" "example" {
  ami           = "ami-b374d5a5"
  instance_type = "t2.micro"

  provisioner "local-exec" {
    command = "echo ${aws_instance.example.public_ip} > ip_address.txt"
  }
}
```

This adds a `provisioner` block within the `resource` block. Multiple `provisioner` blocks can be added to define [multiple provisioning steps](https://www.terraform.io/docs/provisioners/index.html).

### Running Provisioners

Provisioners are only run when a resource is created. They are not a replacement for configuration management and changing the software of an already-running server, and are instead just meant as a way to bootstrap a server. For configuration management, you should use Terraform provisioning to invoke a real configuration management solution.

Make sure that your infrastructure is [destroyed](https://www.terraform.io/intro/getting-started/destroy.html) if it isn't already, then run `apply`:

```
$ terraform apply
# ...

aws_instance.example: Creating...
  ami:           "" => "ami-b374d5a5"
  instance_type: "" => "t2.micro"
aws_eip.ip: Creating...
  instance: "" => "i-213f350a"

Apply complete! Resources: 2 added, 0 changed, 0 destroyed.
```

Terraform will output anything from provisioners to the console, but in this case there is no output. However, we can verify everything worked by looking at the `ip_address.txt` file:

```
$ cat ip_address.txt
54.192.26.128
```

It contains the IP, just as we asked!

### Failed Provisioners and Tainted Resources

If a resource successfully creates but fails during provisioning, Terraform will error and mark the resource as "tainted." A resource that is tainted has been physically created, but can't be considered safe to use since provisioning failed.

When you generate your next execution plan, Terraform will not attempt to restart provisioning on the same resource because it isn't guaranteed to be safe. Instead, Terraform will remove any tainted resources and create new resources, attempting to provision them again after creation.

Terraform also does not automatically roll back and destroy the resource during the apply when the failure happens, because that would go against the execution plan: the execution plan would've said a resource will be created, but does not say it will ever be deleted. If you create an execution plan with a tainted resource, however, the plan will clearly state that the resource will be destroyed because it is tainted.

### Destroy Provisioners

Provisioners can also be defined that run only during a destroy operation. These are useful for performing system cleanup, extracting data, etc.

For many resources, using built-in cleanup mechanisms is recommended if possible (such as init scripts), but provisioners can be used if necessary.

If you need to use destroy provisioners, please see the [provisioner documentation](https://www.terraform.io/docs/provisioners/index.html).
