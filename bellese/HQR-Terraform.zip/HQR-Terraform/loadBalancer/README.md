Terraform scripts for provisioning Load Balancers
=================================

This data source can prove useful when a module accepts an LB as an input variable and needs to, for example, determine the security groups associated with it, etc.

Usage
-----
```
resource "aws_lb" "test" {
  name            = "test-lb-tf"
  internal        = false
  security_groups = ["${aws_security_group.lb_sg.id}"]
  subnets         = ["${aws_subnet.public.*.id}"]
  enable_deletion_protection = true
   access_logs {
    bucket = "${aws_s3_bucket.lb_logs.bucket}"
    prefix = "test-lb"
               }
	tags {
    Environment = "production"
        }
}
```

The following arguments are supported:
--------------------------------------


- name - (Optional) The name of the LB. This name must be unique within your AWS account, can have a maximum of 32 characters, must contain only alphanumeric - characters or hyphens, and must not begin or end with a hyphen. If not specified, Terraform will autogenerate a name beginning with tf-lb.
- name_prefix - (Optional) Creates a unique name beginning with the specified prefix. Conflicts with name.
- internal - (Optional) If true, the LB will be internal.
- load_balancer_type - (Optional) The type of load balancer to create. Possible values are application or network. The default value is application.
- security_groups - (Optional) A list of security group IDs to assign to the LB. Only valid for Load Balancers of type application.
- access_logs - (Optional) An Access Logs block. Access Logs documented below.
- subnets - (Optional) A list of subnet IDs to attach to the LB. Subnets cannot be updated for Load Balancers of type network. Changing this value will  for  load balancers of type network will force a recreation of the resource.
- subnet_mapping - (Optional) A subnet mapping block as documented below.
- idle_timeout - (Optional) The time in seconds that the connection is allowed to be idle. Default: 60.
- enable_deletion_protection - (Optional) If true, deletion of the load balancer will be disabled via the AWS API. This will prevent Terraform from deleting the load balancer. Defaults to false.
- ip_address_type - (Optional) The type of IP addresses used by the subnets for your load balancer. The possible values are ipv4 and dualstack
- tags - (Optional) A mapping of tags to assign to the resource.


Attributes 
-----------

- id - The ARN of the load balancer (matches arn).
- arn_suffix - The ARN suffix for use with CloudWatch Metrics.
- dns_name - The DNS name of the load balancer.
- canonical_hosted_zone_id - The canonical hosted zone ID of the load balancer.
- zone_id - The canonical hosted zone ID of the load balancer (to be used in a Route 53 Alias record).

## Reference Guide

[Application load balancing](https://www.terraform.io/docs/providers/aws/r/lb.html)